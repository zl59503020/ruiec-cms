-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 11 月 20 日 11:07
-- 服务器版本: 5.5.24-log
-- PHP 版本: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ruieccms`
--
DROP DATABASE `ruieccms`;
CREATE DATABASE `ruieccms` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ruieccms`;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_404_logs`
--
-- 创建时间: 2012 年 11 月 01 日 09:52
--

DROP TABLE IF EXISTS `ruiec_404_logs`;
CREATE TABLE IF NOT EXISTS `ruiec_404_logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `surl` varchar(255) DEFAULT NULL COMMENT '来源路径',
  `furl` varchar(255) NOT NULL DEFAULT '' COMMENT '访问路径',
  `time` varchar(255) DEFAULT NULL COMMENT '操作时间',
  `ip` varchar(255) DEFAULT NULL COMMENT '操作IP地址',
  `userAgent` varchar(500) DEFAULT NULL COMMENT '用户代理信息',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='404记录日志表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_ads`
--
-- 创建时间: 2012 年 11 月 01 日 10:28
--

DROP TABLE IF EXISTS `ruiec_ads`;
CREATE TABLE IF NOT EXISTS `ruiec_ads` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL COMMENT '广告标题',
  `type` int(11) DEFAULT '0' COMMENT '广告类型 0:文字 1:图片 2:flash 3:自定义',
  `url` varchar(255) DEFAULT NULL COMMENT '广告链接',
  `content` text COMMENT '内容',
  `starttime` varchar(255) DEFAULT NULL COMMENT '开始时间',
  `overtime` varchar(255) DEFAULT NULL COMMENT '结束时间',
  `width` int(11) DEFAULT '0' COMMENT '宽',
  `height` int(11) DEFAULT '0' COMMENT '高',
  `time` varchar(255) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_key_link`
--
-- 创建时间: 2012 年 11 月 01 日 10:13
--

DROP TABLE IF EXISTS `ruiec_key_link`;
CREATE TABLE IF NOT EXISTS `ruiec_key_link` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL COMMENT '关键词',
  `url` varchar(255) DEFAULT NULL COMMENT '链接地址',
  `maxcount` int(11) DEFAULT '3' COMMENT '最多出现次数',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='内链表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_logs`
--
-- 创建时间: 2012 年 11 月 01 日 09:30
--

DROP TABLE IF EXISTS `ruiec_logs`;
CREATE TABLE IF NOT EXISTS `ruiec_logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `content` text NOT NULL COMMENT '内容说明',
  `time` varchar(255) DEFAULT '' COMMENT '操作时间',
  `ip` varchar(255) DEFAULT NULL COMMENT '操作IP',
  `userAgent` varchar(500) DEFAULT NULL COMMENT '用户代理信息',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='记录日志表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_member_groups`
--
-- 创建时间: 2012 年 11 月 01 日 10:44
--

DROP TABLE IF EXISTS `ruiec_member_groups`;
CREATE TABLE IF NOT EXISTS `ruiec_member_groups` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '分组名称',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户分组表' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `ruiec_member_groups`
--

INSERT INTO `ruiec_member_groups` (`Id`, `name`) VALUES
(1, '超级管理员'),
(2, '管理员'),
(3, 'VIP会员'),
(4, '会员');

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_members`
--
-- 创建时间: 2012 年 11 月 01 日 10:43
--

DROP TABLE IF EXISTS `ruiec_members`;
CREATE TABLE IF NOT EXISTS `ruiec_members` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) DEFAULT NULL COMMENT '密码',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `groupid` int(11) DEFAULT '1' COMMENT '组',
  `truename` varchar(255) DEFAULT NULL COMMENT '真实姓名',
  `sex` int(11) DEFAULT '1' COMMENT '性别',
  `company` varchar(255) DEFAULT NULL COMMENT '公司',
  `phone` varchar(255) DEFAULT NULL COMMENT '电话',
  `qq` varchar(255) DEFAULT NULL COMMENT 'QQ号码',
  `logincount` int(11) DEFAULT '0' COMMENT '登录次数',
  `lastlogintime` varchar(255) DEFAULT NULL COMMENT '上一次登录时间',
  `lastloginip` varchar(255) DEFAULT NULL COMMENT '上一次登录IP',
  `time` varchar(255) DEFAULT NULL COMMENT '注册时间',
  `ip` varchar(255) DEFAULT NULL COMMENT '注册IP',
  `userAgent` varchar(500) DEFAULT NULL COMMENT '注册用户代理',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `ruiec_members`
--

INSERT INTO `ruiec_members` (`Id`, `username`, `password`, `email`, `groupid`, `truename`, `sex`, `company`, `phone`, `qq`, `logincount`, `lastlogintime`, `lastloginip`, `time`, `ip`, `userAgent`) VALUES
(1, 'admin', 'cade3ae501d034295e1d52cf5f8219b4', '348666262@qq.com', 1, 'ZongLiang', 1, '深圳源中瑞科技有限公司', '13418371347', '348666262', 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_oauth`
--
-- 创建时间: 2012 年 11 月 01 日 10:50
--

DROP TABLE IF EXISTS `ruiec_oauth`;
CREATE TABLE IF NOT EXISTS `ruiec_oauth` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '会员名',
  `site` varchar(30) NOT NULL DEFAULT '' COMMENT '第三方平台',
  `openid` varchar(255) NOT NULL DEFAULT '' COMMENT '用户唯一标识',
  `nickname` varchar(255) NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '空间地址',
  `logintimes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次登录',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '绑定时间',
  PRIMARY KEY (`Id`),
  KEY `username` (`username`),
  KEY `site` (`site`,`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='一键登录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_question_verify`
--
-- 创建时间: 2012 年 11 月 01 日 09:58
--

DROP TABLE IF EXISTS `ruiec_question_verify`;
CREATE TABLE IF NOT EXISTS `ruiec_question_verify` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL COMMENT '问题',
  `answer` varchar(255) DEFAULT NULL COMMENT '答案',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='问题验证表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_search_keys`
--
-- 创建时间: 2012 年 11 月 01 日 09:55
--

DROP TABLE IF EXISTS `ruiec_search_keys`;
CREATE TABLE IF NOT EXISTS `ruiec_search_keys` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL COMMENT '关键字',
  `count` int(11) DEFAULT '0' COMMENT '次数',
  `ishot` int(1) DEFAULT '0' COMMENT '是否热门',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='搜索关键字表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_seo_infos`
--
-- 创建时间: 2012 年 11 月 01 日 10:34
--

DROP TABLE IF EXISTS `ruiec_seo_infos`;
CREATE TABLE IF NOT EXISTS `ruiec_seo_infos` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT 'key',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `keywords` varchar(255) DEFAULT NULL COMMENT '关键词',
  `description` text COMMENT '描述',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='SEO信息表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_shield_keys`
--
-- 创建时间: 2012 年 11 月 01 日 10:00
--

DROP TABLE IF EXISTS `ruiec_shield_keys`;
CREATE TABLE IF NOT EXISTS `ruiec_shield_keys` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL COMMENT '关键字',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屏蔽关键字' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_spider_logs`
--
-- 创建时间: 2012 年 11 月 01 日 10:10
--

DROP TABLE IF EXISTS `ruiec_spider_logs`;
CREATE TABLE IF NOT EXISTS `ruiec_spider_logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '蜘蛛名称',
  `surl` varchar(255) DEFAULT NULL COMMENT '来源URL',
  `furl` varchar(255) DEFAULT NULL COMMENT '爬行地址',
  `time` varchar(255) DEFAULT NULL COMMENT '爬行时间',
  `ip` varchar(255) DEFAULT NULL COMMENT '蜘蛛IP',
  `userAgent` varchar(500) DEFAULT NULL COMMENT '代理信息',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='蜘蛛爬行日志' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_tags`
--
-- 创建时间: 2012 年 11 月 01 日 10:19
--

DROP TABLE IF EXISTS `ruiec_tags`;
CREATE TABLE IF NOT EXISTS `ruiec_tags` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `content` text COMMENT '内容',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='自定义标签表' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ruiec_upload_logs`
--
-- 创建时间: 2012 年 11 月 01 日 09:47
--

DROP TABLE IF EXISTS `ruiec_upload_logs`;
CREATE TABLE IF NOT EXISTS `ruiec_upload_logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL DEFAULT '' COMMENT '上传用户',
  `fileurl` varchar(500) NOT NULL DEFAULT '' COMMENT '文件路径',
  `filetype` varchar(255) DEFAULT NULL COMMENT '文件类型',
  `filesize` varchar(255) DEFAULT NULL COMMENT '文件大小',
  `time` varchar(255) DEFAULT NULL COMMENT '操作时间',
  `ip` varchar(255) DEFAULT NULL COMMENT '上传IP地址',
  `userAgent` varchar(500) DEFAULT NULL COMMENT '操作用户代理信息',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传记录表' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
